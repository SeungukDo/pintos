#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  /*int intr_num = (int)f->esp;
  int arg[3];

  switch(intr_num){
    case SYS_HALT:
      halt();
      break;

    case SYS_EXIT:
      handler_arg(1, arg, &f->esp);

      exit(arg[0]);
      break;

    case SYS_EXEC:
      handler_arg(1, arg, &f->esp);

      exec((const char*)arg[0]);
      break;

    case SYS_WAIT:
      handler_arg(1, arg, &f->esp);
      wait(arg[0]);
      break;
    
    case SYS_CREATE:
      //create();
      break;

    case SYS_REMOVE:
      //remove();
      break;

    case SYS_OPEN:
      //open();
      break;

    case SYS_FILESIZE:
      //filesize();
      break;

    case SYS_READ:
      //read();
      break;

    case SYS_WRITE:
      //write();
      break;

    case SYS_SEEK:
      //seek();
      break;
    
    case SYS_TELL:
      //tell();
      break;

    case SYS_CLOSE:
      //close();
      break;
  }
*/
  printf ("system call!\n");
  thread_exit ();
}

void handler_arg(int num, int*arg, void* esp){
  void* temp_esp = esp + 4;
  for(int i = 0; i < num; i++){
    arg[i] = *(int *)temp_esp;
    temp_esp += 4;
  }
}

void halt(){
  shutdown_power_off();
}

void exit(int status){
  printf("%s: exit(%d)\n", thread_current()->name, status);
  thread_exit();
}

void exec(const char* cmd_line){

}

int wait(){

}

bool create(const char* file, unsigned initial_size){

}

bool remove(const char* file){

}

int open(const char* file){

}

int filesize(int fd){

}

int read(int fd, void* buffer, unsigned size){

}

int write(int fd, const void* buffer, unsigned size){

}

void seek(int fd, unsigned position){

}

unsigned tell(int fd){

}

void close(int fd){

}